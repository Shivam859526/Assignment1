import pandas as pd
import sys
import os

sys.path.append(
    os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..")
    )
)

from src.rag_pipeline import load_pipeline, ask_question

chain = load_pipeline()

df = pd.read_csv(
    "evaluation/evaluation_dataset.csv"
)

results = []

for _, row in df.iterrows():

    question = row["question"]

    response = ask_question(
        chain,
        question
    )

    results.append({
        "question": question,
        "ground_truth": row["ground_truth"],
        "baseline_answer": response["answer"]
    })

pd.DataFrame(results).to_csv(
    "evaluation/results/baseline_results.csv",
    index=False
)

print("Baseline evaluation dataset generated")