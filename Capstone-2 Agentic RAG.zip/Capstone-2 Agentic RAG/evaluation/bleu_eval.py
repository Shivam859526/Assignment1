import pandas as pd
from nltk.translate.bleu_score import sentence_bleu

df=pd.read_csv(
    "evaluation/results/agentic_results.csv"
)

scores=[]

for _,row in df.iterrows():

    bleu = sentence_bleu(
        [row["ground_truth"].split()],
        row["agentic_answer"].split()
    )

    scores.append(bleu)

print("Average BLEU:",sum(scores)/len(scores))