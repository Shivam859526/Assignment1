import pandas as pd
from src.agent import workflow

df = pd.read_csv(
    "evaluation/evaluation_dataset.csv"
)

results=[]

for _,row in df.iterrows():

    question=row["question"]

    answer=workflow.invoke(question)

    results.append({
        "question":question,
        "ground_truth":row["ground_truth"],
        "agentic_answer":answer
    })

pd.DataFrame(results).to_csv(
    "evaluation/results/agentic_results.csv",
    index=False
)

print("Saved Agentic Results")