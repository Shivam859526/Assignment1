import pandas as pd
from rouge_score import rouge_scorer

df=pd.read_csv(
    "evaluation/results/agentic_results.csv"
)

scorer = rouge_scorer.RougeScorer(
    ["rouge1","rouge2","rougeL"],
    use_stemmer=True
)

r1=[]
r2=[]
rl=[]

for _,row in df.iterrows():

    score = scorer.score(
        row["ground_truth"],
        row["agentic_answer"]
    )

    r1.append(score["rouge1"].fmeasure)
    r2.append(score["rouge2"].fmeasure)
    rl.append(score["rougeL"].fmeasure)

print("ROUGE1:",sum(r1)/len(r1))
print("ROUGE2:",sum(r2)/len(r2))
print("ROUGEL:",sum(rl)/len(rl))
