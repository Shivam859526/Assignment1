import pandas as pd
import sys
import os

sys.path.append(
    os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..")
    )
)

from src.rag_pipeline import load_pipeline, ask_question

chain = load_pipeline()

df = pd.read_csv(
    "evaluation/evaluation_dataset.csv"
)

results = []

for _, row in df.iterrows():

    question = row["question"]

    response = ask_question(
        chain,
        question
    )

    results.append({
        "question": question,
        "answer": response["answer"],
        "contexts": response["retrieved_docs"],
        "ground_truth": row["ground_truth"]
    })

pd.DataFrame(results).to_csv(
    "evaluation/results/ragas_input.csv",
    index=False
)

print("RAGAS input created")